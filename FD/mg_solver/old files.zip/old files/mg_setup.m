function [grid_matrices,restrict,interp] = mg_setup(A,numlev,bc,dim)
%% MG_SETUP: Constructs a hierarchy of Galerkin coarse grid matrices
%            and interpolation operators for a Helmholtz/Laplace PDE problem   
%  Use:
%  [galerkin_mat,intergrid] = mg_setup(A, numlev,bc,dim)
%
%  Input: 
%  A:         Matrix on finest grid
%  numlev:    Number of levels (number of coarse grids)
%  bc:        Type of boundary conditions:      
%             'dir' for homogeneous dirichlet bc's
%             'som' for sommerfeld bc's 
%  dim:        Dimension (1 or 2)
%
%  Output:
%  grid_matrices: Cell array with Galerkin matrices 
%                 (grid_matrices{i}: Galerkin matrix level i)                  
%
%  restrict:      Cell array with restriction operators
%                 (restrict_op{i}:restriction operator from i to i+1)
%
%  interp:     Cell array with interpolation operators
%              (interp_op{i}:restriction operator from i+1 to i)
%
%  Author:      Luis Garcia Ramos, 
%               Institut fur Mathematik, TU Berlin
%               Version 0.1, Feb 2016
%
%
%%  Construction of restriction and interpolation matrices

npf   = length(A);
if (dim==2); 
    npf = round(sqrt(npf));  
end  %fix this for 2-D case
npc   = round((npf-1)/2);

restrict  = cell(numlev-1,1);    %restrict{i}: fw restriction grid i to grid i+1 
interp    = cell(numlev-1,1);    %interp{i}: lin interp grid i+1 to grid i
grid_matrices  = cell(numlev,1); %grid_matrices{i}: Galerkin matrix at level i

%Level 1 
grid_matrices{1} = A;
restrict{1}  = fwrestriction(npf,dim);    %fw restriction, grid 1 to grid 2 
interp{1}    = lininterpol(npc,dim);      %lin interp, grid 2 to grid 1
 
 
if numlev==1
    return;
end

switch bc
    case 'dir'
        for i=2:numlev-1
            npf = npc;  npc = ceil((npf-1)/2);
            grid_matrices{i} = sparse(restrict{i-1}*grid_matrices{i-1}*interp{i-1}); %Coarse grid Galerkin matrix
            restrict{i}  = fwrestriction(npf,dim);                                   %fw restriction, grid i to grid i+1 
            interp{i}    = lininterpol(npc,dim);                                     %lin interp, grid i+1 to grid 
        end
        grid_matrices{numlev} = sparse(restrict{numlev-1}*grid_matrices{numlev-1}*interp{numlev-1});
end       
end

