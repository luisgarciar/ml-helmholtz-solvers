function [x] = wJacobi(A,b,x0,w,numit)
%% WJACOBI Weighted Jacobi iteration
%  Applies numit iterations of the weighted Jacobi method to solve Ax=b
%
%  Input:
%   A, b: Matrix of the linear system and right hand side
%   x0: initial guess
%   w: damping parameter
%   numit: number of iterations 
%
%  Output:
%   x: solution
%
%  Author: Luis Garcia Ramos, 
%          Institut fur Mathematik, TU Berlin
%          Version 0.1, Feb 2016
%% 

[n,m]=size(A);
assert(n==m, 'Incorrect matrix size');

x = x0;
D = spdiags(diag(A),0,n,n);
N = D-A;

for i=1:numit
    x = w*(D\(N*x)+D\b)+(1-w)*x;
end

end