function [v_sol] = Vcycle(grid_matrices,restrict_op,interp_op,v_init,f,nu,mu,w)
%% VCYCLE Solves the Helmholtz equation using a multigrid V-cycle.
%
%   Input:
%       grid_matrices:   cell array with Helmholtz matrices on all
%                        levels
%       restrict_op:     cell array with restriction operators
%       interp_op:       cell array with interpolation operators
%       v:               Initial guess
%       f:               right-hand side
%       nu:              number of presmoothing steps
%       mu:              number of postsmoothing steps
%       levs:            number of multigrid levels
%
%   Output       
%       v:     solution computed with the multigrid V-cycle   
%
%   Author: Luis Garcia Ramos,          
%           Institut fur Mathematik, TU Berlin
%           Version 0.1, Feb 2016
%
%%    
    if length(grid_matrices) == 1 %If on coarse level, solve exactly
        v_sol = grid_matrices{1,1}\f;
        pause;
        return;
        
    else
        %Presmoothing and computation of the residual
        s = length(grid_matrices{1,1});
       % fprintf('Initiatiing presmoothing on grid of size %d \n', s);
        v_sol   = wJacobi(grid_matrices{1,1},f,v_init,w,nu);
        %fprintf('Successful presmoothing in grid of size %d \n', length(v_sol));
        r       = f-grid_matrices{1,1}*v_sol;
        %pause;

        %Restriction of the residual to coarse grid
        fc   = restrict_op{1,1}*r; 
        nc   = length(fc);
        vc   = zeros(nc,1);
        %fprintf('Size of restricted residual is %d \n', nc);
        levs = length(grid_matrices);
        %fprintf('Number of remaining levels is %d \n', levs);
        %pause;
        
        %Calling Vcycle to solve the error equation
        fprintf('Length of coarse grid vector is %d \n', length(vc));      
        if(levs >2)
            fprintf('Recursive call to V-cycle \n');
            vc  = Vcycle(grid_matrices(2:levs),restrict_op(2:levs-1),interp_op(2:levs-1),vc,fc,nu,mu,w); 
        elseif(levs==2)
            fprintf('Recursive call to V-cycle in level 2 \n');     
            vc = Vcycle(grid_matrices(2:2),restrict_op(1:1),interp_op(1:1),vc,fc,nu,mu,w);
        end
            %Prolongation and correction on current grid
            v_sol = v_sol + interp_op{1,1}*vc;
            fprintf('initiating Postsmoothing in grid of size %d \n', length(v_sol))
            v_sol  = wJacobi(grid_matrices{1,1},f,v_sol,mu,w);
            fprintf('Successful postsmoothing in grid of size %d \n', length(v_sol));
    end   
   
end

