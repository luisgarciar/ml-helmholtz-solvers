function [x] = rbgaussseidel(A,b,x0,numit)
%% RBGAUSSSEIDEL Red-black Gauss seidel iteration
%  Applies numit iterations of the Red-Black Gauss Seidel
%  iteration to solve Ax=b with initial guess x0
%
%  Input:
%   A, b: Matrix of the linear system and right hand side
%   x0: initial guess
%   numit: number of iterations 
%
%  Output:
%   x: solution
%
%  Author: Luis Garcia Ramos, 
%          Institut fur Mathematik, TU Berlin
%          Version 0.1, Jun 2016
%% 
[n,m]=size(A);
assert(n==m, 'Incorrect matrix size');

%
np = round(sqrt(n));  %number of 1D interior discretization points
P  = rb_reorder(np);  %permutation matrix for red-black ordering  

%apply permutation to all data
x = P*x0;  Pb=P*b;
PAP = P*A*P';

%run Gauss-Seidel on permuted system
D = spdiags(diag(PAP),0,n,n);
L = tril(PAP); U = triu(PAP);
M = D+L; N = -U;

for i=1:numit
    x = M\(N*x+Pb);
end

%reorder solution and return
x=P'*x;
end