%Test of functions mg_setup, lin_interpol, fwrestriction
clear all; 

lev = 3;                           %number of (coarse) levels
npc = 3;                           %number of points in coarsest grid 
npf = (2^lev)*npc+(2^lev-1);       %number of points in finest grid 
bc  = 'dir';
k   =  0;
dim =  1;

A = helmholtz(k,npf,bc);
b = zeros(length(A),1); b(ceil(length(A)/2),1)=1;
Y = fwrestriction(npf,1);
v = zeros(length(A),1);
numit = 100;
w =2/3;

Z = lininterpol(npc, 2);
Z = fwrestriction(npf, 2);

%[grid_matrices,restrict,interp] = mg_setup(A,lev,bc);

%% Test of weighted Jacobi iteration
% numit=5;
% w=2/3;
% B = 5+5*randn(10,10);
% D= diag(diag(B));
% B = B+100*D;
% x = rand(10,1);
% f = B*x;
% v = zeros(10,1);
% 
% M = diag(diag(B));
% N = M-B;
% It= M\N;
% sprad = max(abs(eig(It)))
% 
% n1 = norm(f-B*v);
% v =  wJacobi(B,f,v,w,numit);
% n2 = norm(f-B*v);

%%  Test of V-cycle on a Poisson problem
% Matrix hierarchy and right hand side
 [grid_matrices,restrict,interp] = mg_setup(A,lev,bc,dim);
 b = zeros(length(A),1); b(ceil(length(A)/2),1)=npf;
 v_init = zeros(length(A),1);
 
% Parameters of V-cycle and Jacobi iteration
npre = 3; npos = 3; w  = 2/3; smo = 'wjac', numcycles = 10;
r0 = norm(b-A*v);

%for i=1:5    
    sol    = Vcycle(grid_matrices,restrict,interp,v_init,b,npre,npos,w,smo,numcycles);
 %   v_init = sol;
%end

r1 = norm(b-A*sol);