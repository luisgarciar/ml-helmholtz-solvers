function [x] = gaussseidel(A,b,x0,numit)
%% GAUSSSEIDEL Gauss seidel iteration
%  Applies numit iterations of the Gauss-Seidel method 
%  with initial guess x0 to solve Ax=b
%
%  Input:
%   A, b: Matrix of the linear system and right hand side
%   x0: initial guess
%   numit: number of iterations 
%
%  Output:
%   x: solution
%
%  Author: Luis Garcia Ramos, 
%          Institut fur Mathematik, TU Berlin
%          Version 1.0, Jun 2016
%% 
[n,m]=size(A);
assert(n==m, 'Incorrect matrix size');

x = x0;
D = spdiags(diag(A),0,n,n);
L = tril(A,-1); U = triu(A,1);
M = D+L; N = -U;

for i=1:numit
    x = M\(N*x+b);
end

end